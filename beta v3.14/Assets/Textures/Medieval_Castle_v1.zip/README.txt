                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1705595
Medieval Castle v1 by sishaar is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

Customized version of http://www.thingiverse.com/thing:1612651

Created with Customizer! http://www.thingiverse.com/apps/customizer/run?thing_id=1612651



# Instructions

Using the following options:

towers_roof_type = 0
island_random_seed = 178
next_levels_symmetry = No
generate_corbels = Yes
children_width_ratio = 0.7
random_seed = 1
window_width_base = 2.5
building_height = 8
building_width = 0
brick_space = 0.2
island = Yes
what_to_generate = 1
towers_height = 0
turrets_roof_type = 0
island_width = 80
first_level_symmetry = No
towers_number_of_sides = 0
floor_height = 5
turrets_number_of_sides = 0
brick_horz = 12
window_coverage = 0.3
max_recursion = 2
children = 3
brick_height = 1.5
children_height_ratio = 0.7
generate_roof_decorations = Yes
generate_windows = Yes
brick_space_depth = 0.1
generate_bricks = Yes
island_height = 25
towers_width = 0
building_number_of_sides = 0
roof_pointed_ratio = 1.2
building_roof_type = 0
generate_details = No